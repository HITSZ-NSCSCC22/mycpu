//  (c) Copyright 2013 Xilinx, Inc. All rights reserved.
//
//  This file contains confidential and proprietary information
//  of Xilinx, Inc. and is protected under U.S. and
//  international copyright and other intellectual property
//  laws.
//
//  DISCLAIMER
//  This disclaimer is not a license and does not grant any
//  rights to the materials distributed herewith. Except as
//  otherwise provided in a valid license issued to you by
//  Xilinx, and to the maximum extent permitted by applicable
//  law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
//  WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
//  AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
//  BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
//  INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
//  (2) Xilinx shall not be liable (whether in contract or tort,
//  including negligence, or under any other theory of
//  liability) for any loss or damage of any kind or nature
//  related to, arising under or in connection with these
//  materials, including for any direct, or any indirect,
//  special, incidental, or consequential loss or damage
//  (including loss of data, profits, goodwill, or any type of
//  loss or damage suffered as a result of any action brought
//  by a third party) even if such damage or loss was
//  reasonably foreseeable or Xilinx had been advised of the
//  possibility of the same.
//
//  CRITICAL APPLICATIONS
//  Xilinx products are not designed or intended to be fail-
//  safe, or for use in any application requiring fail-safe
//  performance, such as life-support or safety devices or
//  systems, Class III medical devices, nuclear facilities,
//  applications related to the deployment of airbags, or any
//  other applications that could lead to death, personal
//  injury, or severe property or environmental damage
//  (individually and collectively, "Critical
//  Applications"). Customer assumes the sole risk and
//  liability of any use of Xilinx products in Critical
//  Applications, subject only to applicable laws and
//  regulations governing limitations on product liability.
//
//  THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
//  PART OF THIS FILE AT ALL TIMES.
//-----------------------------------------------------------------------------
// Smoke test program for bit accurate C model

#include <iostream>
#include <vector>
#include <complex>

#define _USE_MATH_DEFINES
#include <math.h>

#include <fstream> // for debug only

#include "div_gen_v5_1_bitacc_cmodel.h"
#include "gmp.h"

using namespace std;

// Debug functions
// Set DEBUG to 1 for more verbose output
#define DEBUG 0

static void msg_print(void* dummy, int error, const char* msg)
{
  std::cout << msg << std::endl;
}
// End of debug functions


#define DATA_SIZE 20

void mpz_print(mpz_t val,
	       int base)
{
  char msg_seg[200];
  mpz_get_str(msg_seg, base, val);
  cerr << msg_seg;
}

int main()
{
  int return_val = 0;

  cout << "C model version = " << xip_div_gen_v5_1_get_version() << endl;

  // Create a configuration structure
  xip_div_gen_v5_1_config config;
  xip_status status = xip_div_gen_v5_1_default_config(&config);

  config.algorithm_type  = XIP_DIV_GEN_V5_1_ALGO_HIGH_RADIX;
  config.divisor_width   = 16;
  config.dividend_width  = 16;
  config.remainder_type  = XIP_DIV_GEN_V5_1_REMTYPE_FRACTIONAL;
  config.fractional_width  = (config.remainder_type ==XIP_DIV_GEN_V5_1_REMTYPE_REMAINDER)?
    config.divisor_width :  //set to divisor width when remainder
    8; //edit this for fractional width

  if (status != XIP_STATUS_OK) {
    cerr << "ERROR: Could not get C model default configuration" << endl;
    return 1;
  }

  // Create model object
  xip_div_gen_v5_1* pstate;
  pstate = xip_div_gen_v5_1_create(&config, &msg_print, 0);

  if (status != XIP_STATUS_OK) {
    cerr << "ERROR: Could not create C model state object" << endl;
    return 1;
  }

  // Declare any arrays in the request structure and write pointers to them into the request structure
  size_t ii;
  unsigned int num_samples = DATA_SIZE;

  // Create and allocate input data structures
  xip_array_mpz* divisor      = xip_div_gen_v5_1_xip_array_mpz_alloc(num_samples);
  xip_array_mpz* dividend     = xip_div_gen_v5_1_xip_array_mpz_alloc(num_samples);

  // Create and allocate output data structures
  xip_array_mpz* quotient     = xip_div_gen_v5_1_xip_array_mpz_alloc(num_samples);
  xip_array_mpz* remainder    = xip_div_gen_v5_1_xip_array_mpz_alloc(num_samples);
  xip_array_uint* div_by_zero = xip_div_gen_v5_1_xip_array_uint_alloc(num_samples);

  // Declare per-sample variables
  mpz_t    s_divisor, s_dividend, s_quotient, s_remainder;
  mpz_t dummy; // a temporary variable
  mpz_init(s_divisor); //...and allocate
  mpz_init(s_dividend);
  mpz_init(s_quotient);
  mpz_init(s_remainder);
  mpz_init(dummy);
  xip_uint s_div_by_zero;

  //debug output string
  char msg_seg[200];

  //populate data structures with example data
  for (ii = 0; ii < num_samples; ii++) {
    mpz_set_si(s_divisor, (signed long int)(11-ii));
    mpz_set_si(s_dividend, (signed long int)((1<<(config.dividend_width-1))-3*ii-1));

#if(DEBUG)
    cerr << "dividend sample " << ii << " to write = ";
    mpz_print(s_dividend,10);
    cerr << "divisor sample " << ii << " to write = ";
    mpz_print(s_divisor,10);
    cerr << endl;
#endif

    //For defensive programming, this would be a good point to put in range checks on the input operands

    if (xip_div_gen_v5_1_xip_array_mpz_set_data(divisor, s_divisor, ii) != XIP_STATUS_OK)
      cerr << "Error in xip_array_mpz_set_data" << endl;
    if (xip_div_gen_v5_1_xip_array_mpz_set_data(dividend, s_dividend, ii) != XIP_STATUS_OK)
      cerr << "Error in xip_array_mpz_set_data" << endl;
  }

  // Run the model
  cout << "Running the C model..." << endl;
  if (xip_div_gen_v5_1_data_do(pstate, divisor, dividend, quotient, remainder, div_by_zero, num_samples) != XIP_STATUS_OK) {
    cerr << "ERROR: C model did not complete successfully" << endl;
    xip_div_gen_v5_1_xip_array_mpz_destroy(divisor);
    xip_div_gen_v5_1_xip_array_mpz_destroy(dividend);
    xip_div_gen_v5_1_xip_array_mpz_destroy(quotient);
    xip_div_gen_v5_1_xip_array_mpz_destroy(remainder);
    xip_div_gen_v5_1_xip_array_uint_destroy(div_by_zero);
    xip_div_gen_v5_1_destroy(pstate);
    return 1;
  } else {
    cout << "C model completed successfully" << endl;
  }


  // Check response is correct
  for (ii = 0; ii < num_samples; ii++) {
    if (xip_div_gen_v5_1_xip_array_mpz_get_data(divisor, &s_divisor, ii) != XIP_STATUS_OK)
      cerr << "Error in xip_array_mpz_get_data" << endl;
    if (xip_div_gen_v5_1_xip_array_mpz_get_data(dividend, &s_dividend, ii) != XIP_STATUS_OK)
      cerr << "Error in xip_array_mpz_get_data" << endl;
    if (xip_div_gen_v5_1_xip_array_mpz_get_data(quotient, &s_quotient, ii) != XIP_STATUS_OK)
      cerr << "Error in xip_array_mpz_get_data" << endl;

    //Check that div_by_zero agrees with divisor being zero
    if (xip_div_gen_v5_1_xip_array_uint_get_data(div_by_zero, &s_div_by_zero, ii) != XIP_STATUS_OK)
      cerr << "Error in xip_array_uint_get_data" << endl;
    if (mpz_cmp_ui(s_divisor,0) == 0) { //i.e. divisor = 0
      if (s_div_by_zero == 0 ) //i.e. wrong
	cerr << "div_by_zero unset, but expected for sample " << ii << endl;
      else
	cerr << "div_by_zero detected for sample " << ii << endl;
    } else {
      //Quotient and remainder could be garbage if divisor == 0, so only check when divisor != 0
      if (s_div_by_zero == 1 ) //i.e. wrong
	cerr << "div_by_zero set, but unexpected for sample " << ii << endl;

      if (config.remainder_type == XIP_DIV_GEN_V5_1_REMTYPE_REMAINDER) {
	if (xip_div_gen_v5_1_xip_array_mpz_get_data(remainder, &s_remainder, ii) != XIP_STATUS_OK)
	  cerr << "Error in xip_array_mpz_get_data" << endl;
#if(DEBUG)
	cerr << "dividend(decimal) = ";
	mpz_print(s_dividend,10);
	cerr << endl << "divisor (decimal) = ";
	mpz_print(s_divisor,10);
	cerr << endl << "quotient (raw decimal) = ";
	mpz_print(s_quotient,10);
	cerr << endl;
	cerr << "remainder sample (raw decimal) " << ii << " = ";
	mpz_get_str(msg_seg, 10, s_remainder);
	cerr << msg_seg << endl;
#endif
	//Since the quotient is bit-accurate to the VHDL, which expresses output in twos complement,
	//it is necessary to convert quotients with leading 1's into negative numbers
	if(mpz_tstbit(s_quotient,config.dividend_width-1) == 1) {
	  mpz_set_ui(dummy,1);
	  mpz_mul_2exp(dummy, dummy, config.dividend_width);
	  mpz_sub(s_quotient,s_quotient,dummy);
	}
	//Since the remainder is bit-accurate to the VHDL, which expresses output in twos complement,
	//it is necessary to convert remainders with leading 1's into negative numbers
	if(mpz_tstbit(s_remainder,config.divisor_width-1) == 1) {
	  mpz_set_ui(dummy,1);
	  mpz_mul_2exp(dummy, dummy, config.divisor_width);
	  mpz_sub(s_remainder,s_remainder,dummy);
	}
#if(DEBUG)
	cerr << "quotient (signed decimal) = ";
	mpz_print(s_quotient,10);
	cerr << endl;
	cerr << "remainder sample (signed decimal) " << ii << " = ";
	mpz_get_str(msg_seg, 10, s_remainder);
	cerr << msg_seg << endl << endl;
#endif
	//Check that quotient * divisor + remainder = dividend
	mpz_mul(s_quotient,s_quotient,s_divisor); //using quotient to build up equation
	mpz_add(s_quotient,s_quotient,s_remainder);
	if (mpz_cmp(s_quotient,s_dividend) != 0) {
	  cerr << "ERROR: C model data output is incorrect for sample " << ii << endl;
	  return_val = 1;
	} else {
	  cerr << "sample " << ii << " correct" << endl;
	}
      } else {
	//Check that quotient * divisor = dividend within tolerance
#if(DEBUG)
	cerr << "dividend(decimal) = ";
	mpz_print(s_dividend,10);
	cerr << endl << "divisor(decimal) = ";
	mpz_print(s_divisor,10);
	cerr << endl << "quotient and fractional(decimal) = ";
	mpz_print(s_quotient,10);
	cerr << " ("<< config.fractional_width << ") bits are after the binary point" << endl << endl;
#endif
	mpz_mul(s_quotient,s_quotient,s_divisor); //using quotient to build up equation
	mpz_mul_2exp(s_dividend,s_dividend,config.fractional_width);
	mpz_sub(s_quotient, s_quotient, s_dividend);
	mpz_abs(s_quotient,s_quotient);
	mpz_abs(s_divisor,s_divisor);
	if (mpz_cmp(s_quotient, s_divisor) >= 0) { //i.e. error >= divisor
	  cerr << "ERROR:  C model data output is incorrect for sample " << ii << endl;
	  return_val = 1;
	}
      }
    }
  }
  cout << "C model data output is correct" << endl;

  // Clean up
  mpz_clear(s_divisor);
  mpz_clear(s_dividend);
  mpz_clear(s_quotient);
  mpz_clear(s_remainder);
  mpz_clear(dummy);
  xip_div_gen_v5_1_xip_array_mpz_destroy(divisor);
  xip_div_gen_v5_1_xip_array_mpz_destroy(dividend);
  xip_div_gen_v5_1_xip_array_mpz_destroy(quotient);
  xip_div_gen_v5_1_xip_array_mpz_destroy(remainder);
  xip_div_gen_v5_1_xip_array_uint_destroy(div_by_zero);
  cout << "C model input and output data freed" << endl;

  xip_div_gen_v5_1_destroy(pstate);
  cout << "C model destroyed" << endl;

  // We will already have returned if there was an error
  return 0;
}
